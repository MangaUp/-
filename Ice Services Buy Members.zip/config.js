module.exports = {
  bot: {
    owners: ['',''],  // ايدي الاونر

    // الأونرات يعني الي يقدرون يتحكمون بلبوت

    botID: '',    // ايدي البوت

    // ايدي بوتك

    GuildId: '',   // ايدي السيرفير

    ClientId: '',    // ايدي البوت

    serverinvte: '', // انفايت سيرفر

    clientSECRET: '', // Seceret Your Bot

    callbackURL: 'http://fi6.bot-hosting.net:20902/login', //

    // Call Back : تحط كذا  : http:// تكتب Adress حق استضافة /login

    inviteBotUrl: 'Link_Invite_Your_Bot',// انفايت البوت

    TheLinkVerfy : 'https://discord.com/oauth2/authorize?client_id=1288629010368167997&response_type=code&redirect_uri=http%3A%2F%2Ffi6.bot-hosting.net%3A20902%2Flogin&scope=identify+guilds+guilds.join', // رابط اوثو رايز بالصلاحيه ادخال الي سيرفرات

    // TheLinkVerfy : لما تروح موقع ديسكورد دفلبرز https://discord.com/developers/applications/Id_Your_Bot/oauth2
    // 1 - روح خيار Add Redirect 
    // حط CallbackURL فيه و سوي حفظ معلومات
    // بعدين انزل تحت فعل identify + guilds + guilds.json 
    // اختر رابط كال باك 
    // انسخ رابط هذاك و حطه في TheLinkVerfy و بس تم

    prefix : '', // برفكس البوت

    ceatogry : '', // كاتوجري الي يفتح فيها تكت شراء

     TOKEN: '',// توكن 

    Price: 1000 ,    // سعر العضو الواحد

    TraId  : '' , // ايدي الي يتحوله كريديت

    channelId : '', // ايدي روم تم الشراء

    roleId :'', // رتبة Client لي تجي لما شخص يشتري

    LineIce : '', // رابط خط سيرفرك 

    taxchannels : '', // ايدي روم الضريبة

  },
  Log : {
    LogChannelOwners : '', // ايدي روم لوق الأونرات فقط
  },
  website: {
    PORT: '', // بورت حق استضافة لي رافع فيها بوتك 
  }
}